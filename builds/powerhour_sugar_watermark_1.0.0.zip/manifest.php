<?php
$manifest = array (
  'id' => 'POWERHOUR_SUGAR_WATERMARK',
  'name' => 'PowerHour | Watermark',
  'description' => 'Adds watermark to the background if Sugar',
  'version' => '1.0.0',
  'author' => 'Jeff Bickart',
  'is_uninstallable' => 'true',
  'published_date' => '2022-05-18 10:18:43',
  'type' => 'module',
  'remove_tables' => '',
  'acceptable_sugar_versions' => 
  array (
    'exact_matches' => 
    array (
    ),
    'regex_matches' => 
    array (
      0 => '11\\.(.*?)\\.(.*?)',
      1 => '12\\.(.*?)\\.(.*?)',
      2 => '13\\.(.*?)\\.(.*?)',
      3 => '14\\.(.*?)\\.(.*?)',
      4 => '15\\.(.*?)\\.(.*?)',
      5 => '16\\.(.*?)\\.(.*?)',
    ),
  ),
  'acceptable_sugar_flavors' => 
  array (
    0 => 'ENT',
  ),
);
$installdefs = array (
  'id' => 'POWERHOUR_SUGAR_WATERMARK',
  'copy' => 
  array (
    0 => 
    array (
      'from' => '<basepath>/crm/custom/clients/base/layouts/watermark/watermark.php',
      'to' => 'custom/clients/base/layouts/watermark/watermark.php',
    ),
    1 => 
    array (
      'from' => '<basepath>/crm/custom/clients/base/layouts/base/base.js',
      'to' => 'custom/clients/base/layouts/base/base.js',
    ),
    2 => 
    array (
      'from' => '<basepath>/crm/custom/clients/base/api/WatermarkApi.php',
      'to' => 'custom/clients/base/api/WatermarkApi.php',
    ),
    3 => 
    array (
      'from' => '<basepath>/crm/custom/clients/base/views/watermark-headerpane/watermark-headerpane.js',
      'to' => 'custom/clients/base/views/watermark-headerpane/watermark-headerpane.js',
    ),
    4 => 
    array (
      'from' => '<basepath>/crm/custom/clients/base/views/watermark-headerpane/watermark-headerpane.php',
      'to' => 'custom/clients/base/views/watermark-headerpane/watermark-headerpane.php',
    ),
    5 => 
    array (
      'from' => '<basepath>/crm/custom/clients/base/views/watermark-content/watermark-content.js',
      'to' => 'custom/clients/base/views/watermark-content/watermark-content.js',
    ),
    6 => 
    array (
      'from' => '<basepath>/crm/custom/clients/base/views/watermark-content/watermark-content.php',
      'to' => 'custom/clients/base/views/watermark-content/watermark-content.php',
    ),
    7 => 
    array (
      'from' => '<basepath>/crm/custom/clients/base/views/watermark-content/watermark-content.hbs',
      'to' => 'custom/clients/base/views/watermark-content/watermark-content.hbs',
    ),
    8 => 
    array (
      'from' => '<basepath>/crm/custom/Extension/modules/Administration/Ext/Administration/watermark.php',
      'to' => 'custom/Extension/modules/Administration/Ext/Administration/watermark.php',
    ),
  ),
  'language' => 
  array (
    0 => 
    array (
      'from' => '<basepath>/crm/custom/Extension/application/Ext/Language/en_us.watermark.php',
      'to_module' => 'application',
      'language' => 'en_us',
    ),
    1 => 
    array (
      'from' => '<basepath>/crm/custom/Extension/modules/Administration/Ext/Language/en_us.watermark.php',
      'to_module' => 'Administration',
      'language' => 'en_us',
    ),
  ),
);
